#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

int OpenFile(char Name[])
{
    int fd = 0;
    fd = open(Name,O_RDONLY);
    return fd;
}

void ReadFile(int fd)
{
    int Length = 0;
    char Data[100];

    while((Length = read(fd,Data,sizeof(Data))) != 0)
    {
        write(1,Data,Length);
    }
}



int main()
{
    char Fname[20];
    int fd = 0;

    printf("Enter the file name that you want to open : ");
    scanf("%s",Fname);

    fd = OpenFile(Fname);

    if(fd == -1)
    {
        printf("Unable to open file\n");
    }

    ReadFile(fd);

    close(fd);

    return 0;
}